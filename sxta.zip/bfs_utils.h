#ifndef BFS_UTILS_H
#define BFS_UTILS_H

int bfs(int **board, int rows, int cols, int startRow, int startCol, int k, int taskType, int *result);

#endif
